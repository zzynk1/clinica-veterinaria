module cl.duoc.clinica {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;

    exports cl.duoc.clinica.app;
    opens cl.duoc.clinica.app to javafx.graphics;
    opens cl.duoc.clinica.controller to javafx.fxml;
    opens cl.duoc.clinica.dto to com.google.gson;
}
