package cl.duoc.clinica.model;

public enum TipoAtencion {
    CONSULTA("Consulta"), VACUNACION("Vacunación"), CIRUGIA("Cirugía");

    private final String etiqueta;

    TipoAtencion(String etiqueta) { this.etiqueta = etiqueta; }

    public String getEtiqueta() { return etiqueta; }

    @Override
    public String toString() { return etiqueta; }
}
