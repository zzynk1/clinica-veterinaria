package cl.duoc.clinica.model;

import java.time.LocalDate;

public class Vacunacion extends Atencion {
    private final String vacuna;
    private final String lote;
    private final LocalDate proximaDosis;

    public Vacunacion(int id, String paciente, String propietario, String veterinario,
                      LocalDate fecha, String vacuna, String lote, LocalDate proximaDosis) {
        super(id, paciente, propietario, veterinario, fecha);
        this.vacuna = vacuna;
        this.lote = lote;
        this.proximaDosis = proximaDosis;
    }

    public String getVacuna() { return vacuna; }
    public String getLote() { return lote; }
    public LocalDate getProximaDosis() { return proximaDosis; }

    @Override
    public TipoAtencion getTipo() { return TipoAtencion.VACUNACION; }

    @Override
    public String getDetalleEspecifico() {
        return "Vacuna: " + vacuna + "\nLote: " + lote + "\nPróxima dosis: " + proximaDosis;
    }
}
