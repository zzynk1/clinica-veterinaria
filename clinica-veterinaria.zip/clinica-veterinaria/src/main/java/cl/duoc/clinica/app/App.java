package cl.duoc.clinica.app;

import cl.duoc.clinica.dao.DaoException;
import cl.duoc.clinica.util.Alertas;
import cl.duoc.clinica.util.AppContext;
import cl.duoc.clinica.util.Navegador;
import javafx.application.Application;
import javafx.stage.Stage;

public class App extends Application {
    @Override
    public void start(Stage stage) {
        Navegador.iniciar(stage);
        try {
            AppContext.repositorio().cargar();
        } catch (DaoException e) {
            Alertas.error(e.getMessage());
        }
        Navegador.irA("principal");
        stage.setTitle("Clínica Veterinaria - Gestión de Atenciones");
        stage.show();
    }

    public static void main(String[] args) { launch(args); }
}
