package cl.duoc.clinica.repository;

import cl.duoc.clinica.dao.AtencionDao;
import cl.duoc.clinica.model.Atencion;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class AtencionRepository {
    private final AtencionDao dao;
    private final ObservableList<Atencion> atenciones = FXCollections.observableArrayList();

    public AtencionRepository(AtencionDao dao) { this.dao = dao; }

    public ObservableList<Atencion> getAtenciones() { return atenciones; }

    public void cargar() { atenciones.setAll(dao.cargar()); }

    public void guardar() { dao.guardar(atenciones); }

    public void agregar(Atencion a) { atenciones.add(a); }

    public void eliminar(Atencion a) { atenciones.remove(a); }

    public int siguienteId() {
        return atenciones.stream().mapToInt(Atencion::getId).max().orElse(0) + 1;
    }
}
