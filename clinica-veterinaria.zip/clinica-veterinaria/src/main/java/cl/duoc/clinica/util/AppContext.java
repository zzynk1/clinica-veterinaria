package cl.duoc.clinica.util;

import cl.duoc.clinica.dao.AtencionJsonDao;
import cl.duoc.clinica.repository.AtencionRepository;

import java.nio.file.Path;

/** Punto único de acceso al repositorio compartido por los controladores. */
public final class AppContext {
    private static final AtencionRepository REPOSITORIO =
            new AtencionRepository(new AtencionJsonDao(Path.of("data", "atenciones.json")));

    private AppContext() { }

    public static AtencionRepository repositorio() { return REPOSITORIO; }
}
