package cl.duoc.clinica.controller;

import cl.duoc.clinica.model.Atencion;
import cl.duoc.clinica.util.Navegador;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

public class DetalleController {
    @FXML private Label lblTitulo;
    @FXML private Label lblPaciente;
    @FXML private Label lblPropietario;
    @FXML private Label lblVeterinario;
    @FXML private Label lblFecha;
    @FXML private Label lblTipo;
    @FXML private TextArea txtEspecifico;

    public void mostrar(Atencion a) {
        lblTitulo.setText("Atención #" + a.getId());
        lblPaciente.setText(a.getNombrePaciente());
        lblPropietario.setText(a.getPropietario());
        lblVeterinario.setText(a.getVeterinario());
        lblFecha.setText(a.getFecha().toString());
        lblTipo.setText(a.getTipo().getEtiqueta());
        txtEspecifico.setText(a.getDetalleEspecifico());
    }

    @FXML
    private void onVolver() { Navegador.irA("principal"); }
}
