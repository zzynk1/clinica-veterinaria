package cl.duoc.clinica.model;

import java.time.LocalDate;

public abstract class Atencion {
    private final int id;
    private final String nombrePaciente;
    private final String propietario;
    private final String veterinario;
    private final LocalDate fecha;

    protected Atencion(int id, String nombrePaciente, String propietario,
                       String veterinario, LocalDate fecha) {
        this.id = id;
        this.nombrePaciente = nombrePaciente;
        this.propietario = propietario;
        this.veterinario = veterinario;
        this.fecha = fecha;
    }

    public abstract TipoAtencion getTipo();

    /** Texto con los atributos propios de cada tipo de atención. */
    public abstract String getDetalleEspecifico();

    public int getId() { return id; }
    public String getNombrePaciente() { return nombrePaciente; }
    public String getPropietario() { return propietario; }
    public String getVeterinario() { return veterinario; }
    public LocalDate getFecha() { return fecha; }
}
