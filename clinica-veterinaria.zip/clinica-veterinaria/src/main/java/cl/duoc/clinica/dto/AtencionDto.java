package cl.duoc.clinica.dto;

/** Representación plana de una atención para serializar en JSON. */
public class AtencionDto {
    public int id;
    public String tipo;
    public String nombrePaciente;
    public String propietario;
    public String veterinario;
    public String fecha;            // ISO yyyy-MM-dd
    // Consulta
    public String motivo;
    public String diagnostico;
    // Vacunación
    public String vacuna;
    public String lote;
    public String proximaDosis;     // ISO yyyy-MM-dd
    // Cirugía
    public String procedimiento;
    public String anestesia;
    public Integer duracionMinutos;
}
