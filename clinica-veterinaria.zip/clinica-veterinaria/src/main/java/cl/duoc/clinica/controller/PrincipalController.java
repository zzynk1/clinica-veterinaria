package cl.duoc.clinica.controller;

import cl.duoc.clinica.dao.DaoException;
import cl.duoc.clinica.model.Atencion;
import cl.duoc.clinica.model.TipoAtencion;
import cl.duoc.clinica.repository.AtencionRepository;
import cl.duoc.clinica.util.Alertas;
import cl.duoc.clinica.util.AppContext;
import cl.duoc.clinica.util.Navegador;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.ListChangeListener;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.time.LocalDate;

public class PrincipalController {
    @FXML private TextField txtBuscar;
    @FXML private ComboBox<TipoAtencion> cmbTipo;
    @FXML private TableView<Atencion> tablaAtenciones;
    @FXML private TableColumn<Atencion, Number> colId;
    @FXML private TableColumn<Atencion, String> colPaciente;
    @FXML private TableColumn<Atencion, String> colPropietario;
    @FXML private TableColumn<Atencion, String> colTipo;
    @FXML private TableColumn<Atencion, LocalDate> colFecha;
    @FXML private TableColumn<Atencion, String> colVeterinario;
    @FXML private Label lblResumen;

    private final AtencionRepository repo = AppContext.repositorio();
    private FilteredList<Atencion> filtradas;

    @FXML
    private void initialize() {
        colId.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getId()));
        colPaciente.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getNombrePaciente()));
        colPropietario.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getPropietario()));
        colTipo.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getTipo().getEtiqueta()));
        colFecha.setCellValueFactory(c -> new SimpleObjectProperty<>(c.getValue().getFecha()));
        colVeterinario.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getVeterinario()));

        cmbTipo.getItems().setAll(TipoAtencion.values());
        cmbTipo.setPromptText("Todos los tipos");

        // ObservableList -> FilteredList -> SortedList -> TableView
        filtradas = new FilteredList<>(repo.getAtenciones(), a -> true);
        SortedList<Atencion> ordenadas = new SortedList<>(filtradas);
        ordenadas.comparatorProperty().bind(tablaAtenciones.comparatorProperty());
        tablaAtenciones.setItems(ordenadas);
        tablaAtenciones.setPlaceholder(new Label("No hay atenciones para mostrar"));

        txtBuscar.textProperty().addListener((obs, a, b) -> aplicarFiltro());
        cmbTipo.valueProperty().addListener((obs, a, b) -> aplicarFiltro());
        filtradas.addListener((ListChangeListener<Atencion>) c -> actualizarResumen());
        actualizarResumen();
    }

    private void aplicarFiltro() {
        String texto = txtBuscar.getText() == null ? "" : txtBuscar.getText().trim().toLowerCase();
        TipoAtencion tipo = cmbTipo.getValue();
        filtradas.setPredicate(a ->
                (tipo == null || a.getTipo() == tipo)
                && (texto.isEmpty()
                    || a.getNombrePaciente().toLowerCase().contains(texto)
                    || a.getPropietario().toLowerCase().contains(texto)
                    || a.getVeterinario().toLowerCase().contains(texto)));
    }

    private void actualizarResumen() {
        lblResumen.setText("Mostrando " + filtradas.size() + " de " + repo.getAtenciones().size() + " atenciones");
    }

    @FXML
    private void onLimpiarFiltros() {
        txtBuscar.clear();
        cmbTipo.setValue(null);
    }

    @FXML
    private void onNueva() { Navegador.irA("formulario"); }

    @FXML
    private void onVerDetalle() {
        Atencion sel = tablaAtenciones.getSelectionModel().getSelectedItem();
        if (sel == null) {
            Alertas.info("Seleccione una atención de la tabla para ver su detalle.");
            return;
        }
        DetalleController c = Navegador.irA("detalle");
        if (c != null) c.mostrar(sel);
    }

    @FXML
    private void onEliminar() {
        Atencion sel = tablaAtenciones.getSelectionModel().getSelectedItem();
        if (sel == null) {
            Alertas.info("Seleccione una atención para eliminar.");
            return;
        }
        if (Alertas.confirmar("¿Eliminar la atención #" + sel.getId() + " de " + sel.getNombrePaciente() + "?")) {
            repo.eliminar(sel);
        }
    }

    @FXML
    private void onGuardar() {
        try {
            repo.guardar();
            Alertas.info("Datos guardados correctamente en data/atenciones.json");
        } catch (DaoException e) {
            Alertas.error(e.getMessage());
        }
    }

    @FXML
    private void onCargar() {
        try {
            repo.cargar();
            Alertas.info("Se cargaron " + repo.getAtenciones().size() + " atenciones.");
        } catch (DaoException e) {
            Alertas.error(e.getMessage());
        }
    }
}
