package cl.duoc.clinica.dao;

import cl.duoc.clinica.model.Atencion;
import java.util.List;

public interface AtencionDao {
    List<Atencion> cargar();
    void guardar(List<Atencion> atenciones);
}
