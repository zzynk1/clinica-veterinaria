package cl.duoc.clinica.dao;

import cl.duoc.clinica.dto.AtencionDto;
import cl.duoc.clinica.model.*;
import java.time.LocalDate;

final class AtencionMapper {
    private AtencionMapper() { }

    static AtencionDto aDto(Atencion a) {
        AtencionDto d = new AtencionDto();
        d.id = a.getId();
        d.tipo = a.getTipo().name();
        d.nombrePaciente = a.getNombrePaciente();
        d.propietario = a.getPropietario();
        d.veterinario = a.getVeterinario();
        d.fecha = a.getFecha().toString();
        if (a instanceof Consulta c) {
            d.motivo = c.getMotivo();
            d.diagnostico = c.getDiagnostico();
        } else if (a instanceof Vacunacion v) {
            d.vacuna = v.getVacuna();
            d.lote = v.getLote();
            d.proximaDosis = v.getProximaDosis().toString();
        } else if (a instanceof Cirugia c) {
            d.procedimiento = c.getProcedimiento();
            d.anestesia = c.getAnestesia();
            d.duracionMinutos = c.getDuracionMinutos();
        }
        return d;
    }

    static Atencion aModelo(AtencionDto d) {
        LocalDate fecha = LocalDate.parse(d.fecha);
        return switch (TipoAtencion.valueOf(d.tipo)) {
            case CONSULTA -> new Consulta(d.id, d.nombrePaciente, d.propietario,
                    d.veterinario, fecha, d.motivo, d.diagnostico);
            case VACUNACION -> new Vacunacion(d.id, d.nombrePaciente, d.propietario,
                    d.veterinario, fecha, d.vacuna, d.lote, LocalDate.parse(d.proximaDosis));
            case CIRUGIA -> new Cirugia(d.id, d.nombrePaciente, d.propietario,
                    d.veterinario, fecha, d.procedimiento, d.anestesia, d.duracionMinutos);
        };
    }
}
