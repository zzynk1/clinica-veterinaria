package cl.duoc.clinica.util;

public final class Validador {
    private Validador() { }

    public static boolean vacio(String texto) { return texto == null || texto.isBlank(); }

    /** Devuelve el entero positivo o null si el texto no es válido. */
    public static Integer enteroPositivo(String texto) {
        try {
            int n = Integer.parseInt(texto.trim());
            return n > 0 ? n : null;
        } catch (NumberFormatException | NullPointerException e) {
            return null;
        }
    }
}
