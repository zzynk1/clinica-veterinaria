package cl.duoc.clinica.model;

import java.time.LocalDate;

public class Consulta extends Atencion {
    private final String motivo;
    private final String diagnostico;

    public Consulta(int id, String paciente, String propietario, String veterinario,
                    LocalDate fecha, String motivo, String diagnostico) {
        super(id, paciente, propietario, veterinario, fecha);
        this.motivo = motivo;
        this.diagnostico = diagnostico;
    }

    public String getMotivo() { return motivo; }
    public String getDiagnostico() { return diagnostico; }

    @Override
    public TipoAtencion getTipo() { return TipoAtencion.CONSULTA; }

    @Override
    public String getDetalleEspecifico() {
        return "Motivo: " + motivo + "\nDiagnóstico: " + diagnostico;
    }
}
