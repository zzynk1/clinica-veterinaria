package cl.duoc.clinica.dao;

import cl.duoc.clinica.dto.AtencionDto;
import cl.duoc.clinica.model.Atencion;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class AtencionJsonDao implements AtencionDao {
    private static final Type TIPO_LISTA = new TypeToken<List<AtencionDto>>() { }.getType();

    private final Path archivo;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public AtencionJsonDao(Path archivo) { this.archivo = archivo; }

    @Override
    public List<Atencion> cargar() {
        if (Files.notExists(archivo)) {
            return new ArrayList<>();
        }
        try {
            String json = Files.readString(archivo, StandardCharsets.UTF_8);
            List<AtencionDto> dtos = gson.fromJson(json, TIPO_LISTA);
            List<Atencion> resultado = new ArrayList<>();
            if (dtos != null) {
                for (AtencionDto d : dtos) {
                    resultado.add(AtencionMapper.aModelo(d));
                }
            }
            return resultado;
        } catch (IOException | RuntimeException e) {
            throw new DaoException("No se pudo leer el archivo " + archivo, e);
        }
    }

    @Override
    public void guardar(List<Atencion> atenciones) {
        try {
            if (archivo.getParent() != null) {
                Files.createDirectories(archivo.getParent());
            }
            List<AtencionDto> dtos = atenciones.stream().map(AtencionMapper::aDto).toList();
            Files.writeString(archivo, gson.toJson(dtos, TIPO_LISTA), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new DaoException("No se pudo escribir el archivo " + archivo, e);
        }
    }
}
