package cl.duoc.clinica.util;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public final class Navegador {
    private static Stage stage;

    private Navegador() { }

    public static void iniciar(Stage escenario) { stage = escenario; }

    /** Carga la vista indicada y devuelve su controlador. */
    public static <T> T irA(String vista) {
        try {
            FXMLLoader loader = new FXMLLoader(
                    Navegador.class.getResource("/cl/duoc/clinica/view/" + vista + ".fxml"));
            Parent raiz = loader.load();
            if (stage.getScene() == null) {
                stage.setScene(new Scene(raiz));
            } else {
                stage.getScene().setRoot(raiz);
            }
            stage.sizeToScene();
            return loader.getController();
        } catch (IOException e) {
            Alertas.error("No se pudo cargar la vista '" + vista + "': " + e.getMessage());
            return null;
        }
    }
}
