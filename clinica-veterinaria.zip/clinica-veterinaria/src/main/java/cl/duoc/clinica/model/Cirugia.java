package cl.duoc.clinica.model;

import java.time.LocalDate;

public class Cirugia extends Atencion {
    private final String procedimiento;
    private final String anestesia;
    private final int duracionMinutos;

    public Cirugia(int id, String paciente, String propietario, String veterinario,
                   LocalDate fecha, String procedimiento, String anestesia, int duracionMinutos) {
        super(id, paciente, propietario, veterinario, fecha);
        this.procedimiento = procedimiento;
        this.anestesia = anestesia;
        this.duracionMinutos = duracionMinutos;
    }

    public String getProcedimiento() { return procedimiento; }
    public String getAnestesia() { return anestesia; }
    public int getDuracionMinutos() { return duracionMinutos; }

    @Override
    public TipoAtencion getTipo() { return TipoAtencion.CIRUGIA; }

    @Override
    public String getDetalleEspecifico() {
        return "Procedimiento: " + procedimiento + "\nAnestesia: " + anestesia
                + "\nDuración: " + duracionMinutos + " min";
    }
}
