package cl.duoc.clinica.controller;

import cl.duoc.clinica.dao.DaoException;
import cl.duoc.clinica.model.*;
import cl.duoc.clinica.repository.AtencionRepository;
import cl.duoc.clinica.util.*;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

import java.time.LocalDate;

public class FormularioController {
    @FXML private TextField txtPaciente;
    @FXML private TextField txtPropietario;
    @FXML private TextField txtVeterinario;
    @FXML private DatePicker dpFecha;
    @FXML private ComboBox<TipoAtencion> cmbTipo;

    @FXML private VBox panelConsulta;
    @FXML private TextField txtMotivo;
    @FXML private TextField txtDiagnostico;

    @FXML private VBox panelVacunacion;
    @FXML private TextField txtVacuna;
    @FXML private TextField txtLote;
    @FXML private DatePicker dpProximaDosis;

    @FXML private VBox panelCirugia;
    @FXML private TextField txtProcedimiento;
    @FXML private TextField txtAnestesia;
    @FXML private TextField txtDuracion;

    private final AtencionRepository repo = AppContext.repositorio();

    @FXML
    private void initialize() {
        cmbTipo.getItems().setAll(TipoAtencion.values());
        dpFecha.setValue(LocalDate.now());
        cmbTipo.valueProperty().addListener((obs, a, tipo) -> mostrarPanel(tipo));
        mostrarPanel(null);
    }

    private void mostrarPanel(TipoAtencion tipo) {
        alternar(panelConsulta, tipo == TipoAtencion.CONSULTA);
        alternar(panelVacunacion, tipo == TipoAtencion.VACUNACION);
        alternar(panelCirugia, tipo == TipoAtencion.CIRUGIA);
    }

    private void alternar(VBox panel, boolean visible) {
        panel.setVisible(visible);
        panel.setManaged(visible);
    }

    @FXML
    private void onGuardar() {
        String errores = validar();
        if (!errores.isEmpty()) {
            Alertas.error("Corrija los siguientes datos:\n" + errores);
            return;
        }
        int id = repo.siguienteId();
        String pac = txtPaciente.getText().trim();
        String prop = txtPropietario.getText().trim();
        String vet = txtVeterinario.getText().trim();
        LocalDate fecha = dpFecha.getValue();

        Atencion nueva = switch (cmbTipo.getValue()) {
            case CONSULTA -> new Consulta(id, pac, prop, vet, fecha,
                    txtMotivo.getText().trim(), txtDiagnostico.getText().trim());
            case VACUNACION -> new Vacunacion(id, pac, prop, vet, fecha,
                    txtVacuna.getText().trim(), txtLote.getText().trim(), dpProximaDosis.getValue());
            case CIRUGIA -> new Cirugia(id, pac, prop, vet, fecha,
                    txtProcedimiento.getText().trim(), txtAnestesia.getText().trim(),
                    Validador.enteroPositivo(txtDuracion.getText()));
        };
        repo.agregar(nueva);
        try {
            repo.guardar();
        } catch (DaoException e) {
            Alertas.error(e.getMessage());
        }
        Alertas.info("Atención #" + id + " registrada correctamente.");
        Navegador.irA("principal");
    }

    private String validar() {
        StringBuilder e = new StringBuilder();
        if (Validador.vacio(txtPaciente.getText())) e.append("- El nombre del paciente es obligatorio.\n");
        if (Validador.vacio(txtPropietario.getText())) e.append("- El propietario es obligatorio.\n");
        if (Validador.vacio(txtVeterinario.getText())) e.append("- El veterinario es obligatorio.\n");
        LocalDate fecha = dpFecha.getValue();
        if (fecha == null) e.append("- La fecha es obligatoria.\n");
        else if (fecha.isAfter(LocalDate.now())) e.append("- La fecha no puede ser futura.\n");
        TipoAtencion tipo = cmbTipo.getValue();
        if (tipo == null) {
            e.append("- Seleccione el tipo de atención.\n");
            return e.toString();
        }
        switch (tipo) {
            case CONSULTA -> {
                if (Validador.vacio(txtMotivo.getText())) e.append("- El motivo es obligatorio.\n");
                if (Validador.vacio(txtDiagnostico.getText())) e.append("- El diagnóstico es obligatorio.\n");
            }
            case VACUNACION -> {
                if (Validador.vacio(txtVacuna.getText())) e.append("- El nombre de la vacuna es obligatorio.\n");
                if (Validador.vacio(txtLote.getText())) e.append("- El lote es obligatorio.\n");
                LocalDate prox = dpProximaDosis.getValue();
                if (prox == null) e.append("- La próxima dosis es obligatoria.\n");
                else if (fecha != null && !prox.isAfter(fecha))
                    e.append("- La próxima dosis debe ser posterior a la fecha de atención.\n");
            }
            case CIRUGIA -> {
                if (Validador.vacio(txtProcedimiento.getText())) e.append("- El procedimiento es obligatorio.\n");
                if (Validador.vacio(txtAnestesia.getText())) e.append("- El tipo de anestesia es obligatorio.\n");
                if (Validador.enteroPositivo(txtDuracion.getText()) == null)
                    e.append("- La duración debe ser un número entero mayor a 0 (minutos).\n");
            }
        }
        return e.toString();
    }

    @FXML
    private void onCancelar() { Navegador.irA("principal"); }
}
